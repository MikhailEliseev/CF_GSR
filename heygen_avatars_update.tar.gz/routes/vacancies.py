import json
import logging
import requests
import time
from flask import Blueprint, request, jsonify
# ИСПРАВЛЕНО: Убираем circular import
# from app_current_backup import db
from models import Settings
from services.openai_service import OpenAIService

# Настройка логирования
logger = logging.getLogger(__name__)

vacancies_bp = Blueprint('vacancies', __name__)

def extract_sheet_id_and_gid(sheets_url):
    """
    Извлекает sheet_id и gid из Google Sheets URL любого формата.
    
    Поддерживаемые форматы:
    - https://docs.google.com/spreadsheets/u/1/d/ID/edit?gid=123
    - https://docs.google.com/spreadsheets/d/ID/edit?gid=123
    - https://docs.google.com/d/ID/edit
    
    Returns:
        tuple: (sheet_id, gid) или (None, None) если не удалось извлечь
    """
    sheet_id = None
    gid = '0'
    
    try:
        # ВАЖНО: Проверяем более специфичные форматы первыми
        if 'spreadsheets/u/' in sheets_url and '/d/' in sheets_url:
            # Формат с /u/1/d/: /u/1/d/ID/
            parts = sheets_url.split('/d/')
            if len(parts) > 1:
                sheet_id = parts[1].split('/')[0]
        elif 'spreadsheets/d/' in sheets_url:
            # Формат: /spreadsheets/d/ID/
            parts = sheets_url.split('spreadsheets/d/')
            if len(parts) > 1:
                sheet_id = parts[1].split('/')[0]
        elif '/d/' in sheets_url:
            # Стандартный формат: /d/ID/
            parts = sheets_url.split('/d/')
            if len(parts) > 1:
                sheet_id = parts[1].split('/')[0]
        
        # Извлекаем gid из URL параметров
        if 'gid=' in sheets_url:
            gid = sheets_url.split('gid=')[1].split('&')[0].split('#')[0]
        
        return sheet_id, gid
    except Exception as e:
        logger.error(f"Ошибка извлечения ID из URL: {e}")
        return None, None


@vacancies_bp.route('/api/vacancies/parse', methods=['POST'])
def parse_vacancies():
    """Парсинг Google Sheets с помощью OpenAI"""
    try:
        data = request.get_json()
        if not data or 'url' not in data:
            return jsonify({
                "success": False,
                "error": "Не указан URL Google Sheets"
            }), 400
        
        sheets_url = data['url']
        logger.info(f"Начинаем парсинг Google Sheets: {sheets_url}")
        
        # Извлекаем ID таблицы и gid
        sheet_id, gid = extract_sheet_id_and_gid(sheets_url)
        
        if not sheet_id:
            return jsonify({
                "success": False,
                "error": "Не удалось извлечь ID таблицы из URL. Проверьте формат URL."
            }), 400
        
        logger.info(f"ХАРДКОР: Извлечен sheet_id: {sheet_id}, gid: {gid}")
        
        csv_url = f"https://docs.google.com/spreadsheets/d/{sheet_id}/export?format=csv&gid={gid}"
        logger.info(f"ХАРДКОР: CSV URL: {csv_url}")
        
        # Получаем данные из Google Sheets с retry логикой
        max_retries = 3
        for attempt in range(max_retries):
            try:
                response = requests.get(csv_url, timeout=30)
                logger.info(f"ХАРДКОР: Попытка {attempt + 1}, статус: {response.status_code}")
                
                if response.status_code == 200:
                    break
                elif response.status_code == 403:
                    logger.error(f"ХАРДКОР: Доступ запрещен (403). Возможно, таблица не публичная")
                    return jsonify({
                        "success": False,
                        "error": "Таблица не публичная или требует аутентификации. Проверьте настройки доступа к Google Sheets."
                    }), 400
                elif response.status_code == 404:
                    logger.error(f"ХАРДКОР: Таблица не найдена (404)")
                    return jsonify({
                        "success": False,
                        "error": "Таблица не найдена. Проверьте правильность URL."
                    }), 400
                else:
                    logger.warning(f"ХАРДКОР: Ошибка {response.status_code}, попытка {attempt + 1}")
                    if attempt == max_retries - 1:
                        return jsonify({
                            "success": False,
                            "error": f"Ошибка получения данных из Google Sheets: {response.status_code}"
                        }), 400
                    time.sleep(2)  # Пауза перед повтором
                    
            except requests.exceptions.Timeout:
                logger.warning(f"ХАРДКОР: Таймаут, попытка {attempt + 1}")
                if attempt == max_retries - 1:
                    return jsonify({
                        "success": False,
                        "error": "Таймаут при загрузке данных из Google Sheets"
                    }), 400
                time.sleep(2)
            except Exception as e:
                logger.error(f"ХАРДКОР: Ошибка запроса: {e}")
                if attempt == max_retries - 1:
                    return jsonify({
                        "success": False,
                        "error": f"Ошибка подключения к Google Sheets: {str(e)}"
                    }), 400
                time.sleep(2)
        
        csv_data = response.text
        logger.info(f"ХАРДКОР: Получены данные из Google Sheets, размер: {len(csv_data)} символов")
        logger.info(f"ХАРДКОР: Первые 500 символов CSV: {csv_data[:500]}")
        
        # Проверяем, что это действительно CSV данные
        if '<HTML>' in csv_data or '<html>' in csv_data:
            logger.error(f"ХАРДКОР: Получен HTML вместо CSV: {csv_data[:200]}")
            return jsonify({
                "success": False,
                "error": "Получен HTML вместо CSV данных. Возможно, таблица не публичная или требует аутентификации."
            }), 400
        
        # Промпт для OpenAI
        parse_prompt = """
Ты - эксперт по парсингу таблиц вакансий. 

ВАЖНО: 
- Первая строка содержит акции - ИГНОРИРУЙ её
- Вторая строка содержит заголовки колонок
- Данные вакансий начинаются с 3-й строки

Структура таблицы:
- Колонка A: Должность (может быть пустой, тогда смотри метаданные)
- Колонка B: Объект/место работы (ОБЯЗАТЕЛЬНО)
- Колонка C: Оплата/зарплата
- Колонка D: Условия работы (смены, вахта, вычеты)
- Колонка E: Требования (возраст, гражданство, СБ)
- Колонка F: Потребность (количество человек)
- Колонка G: Ответственный менеджер
- Колонка H: Юр.лицо
- Колонка I: Преимущества компании

Извлеки для каждой вакансии:
- position: Должность (из колонки A или B)
- location: Объект/место работы (колонка B)
- salary: Оплата (колонка C)
- conditions: Условия (колонка D)
- requirements: Требования (колонка E)
- positions_needed: Потребность (колонка F)
- manager: Менеджер (колонка G)
- company: Юр.лицо (колонка H)
- benefits: Преимущества (колонка I)

Верни JSON массив объектов. Пропускай строки с акциями и заголовками.

Таблица:
""" + csv_data[:8000]  # Ограничиваем размер для API
        
        # Получаем настройки модуля vacancies
        settings = Settings.query.filter_by(module_name='vacancies').first()
        if not settings:
            return jsonify({
                "success": False,
                "error": "Настройки модуля vacancies не найдены"
            }), 500

        api_keys = settings.get_api_keys()
        openai_key = api_keys.get('openai_api_key')
        if not openai_key:
            return jsonify({
                "success": False,
                "error": "OpenAI API ключ не найден в настройках модуля vacancies"
            }), 500
        
        # Используем OpenAI для парсинга
        openai_service = OpenAIService(api_key=openai_key)
        logger.info(f"Отправляем запрос в OpenAI с промптом длиной {len(parse_prompt)} символов")
        
        try:
            parsed_result = openai_service.generate_text(
                prompt=parse_prompt,
                max_tokens=4000,
                temperature=0.1
            )
            logger.info(f"Получен ответ от OpenAI, длина: {len(parsed_result)} символов")
            logger.info(f"Первые 500 символов ответа: {parsed_result[:500]}")
            
            # Пытаемся извлечь JSON из ответа
            if '```json' in parsed_result:
                json_start = parsed_result.find('```json') + 7
                json_end = parsed_result.find('```', json_start)
                json_str = parsed_result[json_start:json_end].strip()
            elif '[' in parsed_result and ']' in parsed_result:
                json_start = parsed_result.find('[')
                json_end = parsed_result.rfind(']') + 1
                json_str = parsed_result[json_start:json_end]
            else:
                json_str = parsed_result
            
            vacancies = json.loads(json_str)
            
            logger.info(f"Успешно распарсено {len(vacancies)} вакансий")
            logger.info(f"Первая вакансия: {vacancies[0] if vacancies else 'Нет вакансий'}")
            return jsonify({
                "success": True,
                "vacancies": vacancies
            })
            
        except json.JSONDecodeError as e:
            logger.error(f"Ошибка парсинга JSON от OpenAI: {str(e)}")
            logger.error(f"Ответ OpenAI: {parsed_result}")
            return jsonify({
                "success": False,
                "error": f"Ошибка парсинга JSON от OpenAI: {str(e)}"
            }), 500
        
    except Exception as e:
        logger.error(f"Ошибка парсинга вакансий: {str(e)}")
        return jsonify({
            "success": False,
            "error": f"Ошибка парсинга вакансий: {str(e)}"
        }), 500

@vacancies_bp.route('/api/vacancies/upload-csv', methods=['POST'])
def upload_csv_file():
    """Загрузка CSV файла с вакансиями"""
    try:
        if 'file' not in request.files:
            return jsonify({
                "success": False,
                "error": "Файл не найден в запросе"
            }), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({
                "success": False,
                "error": "Файл не выбран"
            }), 400
        
        if not file.filename.endswith('.csv'):
            return jsonify({
                "success": False,
                "error": "Файл должен быть в формате CSV"
            }), 400
        
        # Читаем содержимое файла
        csv_data = file.read().decode('utf-8')
        logger.info(f"ХАРДКОР: Загружен CSV файл, размер: {len(csv_data)} символов")
        logger.info(f"ХАРДКОР: Первые 500 символов CSV: {csv_data[:500]}")
        
        # Используем прямой парсинг (быстро, без OpenAI)
        vacancies = parse_vacancies_direct(csv_data)
        
        logger.info(f"Успешно распарсено {len(vacancies)} вакансий")
        return jsonify({
            "success": True,
            "vacancies": vacancies,
            "count": len(vacancies)
        })
        
    except Exception as e:
        logger.error(f"Ошибка загрузки CSV файла: {str(e)}")
        return jsonify({
            "success": False,
            "error": f"Ошибка загрузки CSV файла: {str(e)}"
        }), 500

@vacancies_bp.route('/api/vacancies/generate-text', methods=['POST'])
def generate_vacancy_text():
    """Генерация текста вакансии через OpenAI"""
    try:
        data = request.get_json()
        if not data or 'vacancy' not in data:
            return jsonify({
                "success": False,
                "error": "Не указаны данные вакансии"
            }), 400
        
        vacancy = data['vacancy']
        logger.info(f"Генерируем текст для вакансии: {vacancy.get('title', 'Без названия')}")
        
        # Получаем настройки модуля vacancies
        settings = Settings.query.filter_by(module_name='vacancies').first()
        if not settings:
            return jsonify({
                "success": False,
                "error": "Настройки модуля vacancies не найдены"
            }), 500

        master_prompt = settings.master_prompt
        if not master_prompt:
            return jsonify({
                "success": False,
                "error": "Master prompt не настроен для модуля vacancies"
            }), 500
        
        # Получаем OpenAI API ключ
        api_keys = settings.get_api_keys()
        openai_key = api_keys.get('openai_api_key')
        if not openai_key:
            return jsonify({
                "success": False,
                "error": "OpenAI API ключ не найден в настройках модуля vacancies"
            }), 500
        
        # Создаем контекст из данных вакансии
        vacancy_context = f"""
Данные вакансии:
- Должность: {vacancy.get('title', '')}
- Объект: {vacancy.get('object', '')}
- Оплата: {vacancy.get('salary', '')}
- Условия: {vacancy.get('conditions', '')}
- Требования: {vacancy.get('requirements', '')}
- Преимущества: {vacancy.get('benefits', '')}
- Потребность: {vacancy.get('positions_needed', '')}
- Менеджер: {vacancy.get('manager', '')}
- Компания: {vacancy.get('company', '')}
- Преимущества компании: {vacancy.get('company_benefits', '')}
"""
        
        # Объединяем master_prompt с контекстом вакансии
        full_prompt = f"{master_prompt}\n\n{vacancy_context}"
        
        # Используем OpenAI для генерации текста
        openai_service = OpenAIService(api_key=openai_key)
        
        try:
            generated_text = openai_service.generate_text(
                prompt=full_prompt,
                max_tokens=2000,
                temperature=0.7
            )
            
            logger.info(f"Успешно сгенерирован текст для вакансии: {vacancy.get('title', 'Без названия')}")
            return jsonify({
                "success": True,
                "text": generated_text
            })
            
        except Exception as e:
            logger.error(f"Ошибка генерации текста через OpenAI: {str(e)}")
            return jsonify({
                "success": False,
                "error": f"Ошибка генерации текста: {str(e)}"
            }), 500
        
    except Exception as e:
        logger.error(f"Ошибка генерации текста вакансии: {str(e)}")
        return jsonify({
            "success": False,
            "error": f"Ошибка генерации текста вакансии: {str(e)}"
        }), 500

@vacancies_bp.route('/api/vacancies/parse-direct', methods=['POST'])
def parse_vacancies_direct_endpoint():
    """НОВЫЙ endpoint для прямого парсинга"""
    try:
        data = request.get_json()
        if not data or 'url' not in data:
            return jsonify({"success": False, "error": "URL не указан"}), 400
        
        sheets_url = data['url']
        
        # Используем функцию для извлечения ID
        sheet_id, gid = extract_sheet_id_and_gid(sheets_url)
        
        if not sheet_id:
            return jsonify({"success": False, "error": "Не удалось извлечь ID таблицы из URL"}), 400
        
        csv_url = f"https://docs.google.com/spreadsheets/d/{sheet_id}/export?format=csv&gid={gid}"
        
        response = requests.get(csv_url)
        if response.status_code != 200:
            return jsonify({"success": False, "error": "Ошибка получения данных из Google Sheets"}), 400
        
        # Используем нашу новую функцию
        vacancies = parse_vacancies_direct(response.text)
        
        return jsonify({
            "success": True,
            "vacancies": vacancies,
            "count": len(vacancies),
            "method": "direct"
        })
        
    except Exception as e:
        logger.error(f"Ошибка: {str(e)}")
        return jsonify({"success": False, "error": str(e)}), 500

def parse_vacancies_direct(csv_data):
    """Прямой парсинг CSV с пропуском акций и заголовков"""
    import csv
    from io import StringIO
    
    try:
        reader = csv.reader(StringIO(csv_data))
        vacancies = []
        skipped_rows = 0
        
        logger.info(f"Начинаем парсинг CSV, размер: {len(csv_data)} символов")
        
        for i, row in enumerate(reader):
            try:
                # Пропускаем первые 2 строки: акции и заголовки
                if i == 0:  # Пропускаем акции
                    skipped_rows += 1
                    continue
                if i == 1:  # Пропускаем заголовки
                    skipped_rows += 1
                    continue
                
                # Проверяем что это вакансия, а не метаданные
                if not row[1].strip():  # Нет объекта - пропускаем
                    continue
                if 'Должность' in row[0] or 'Пол' in row[0]:  # Заголовки - пропускаем
                    continue
                
                # Извлекаем все поля с правильными индексами
                vacancies.append({
                    'position': row[1].strip() if len(row) > 1 else '',  # Колонка B - Объект (должность)
                    'location': row[1].strip() if len(row) > 1 else '',  # Колонка B - Объект
                    'salary': row[2].strip() if len(row) > 2 else '',    # Колонка C - Оплата (ИСПРАВЛЕНО)
                    'conditions': row[3].strip() if len(row) > 3 else '', # Колонка D - Условия (ИСПРАВЛЕНО)
                    'requirements': row[4].strip() if len(row) > 4 else '', # Колонка E - Требования (ИСПРАВЛЕНО)
                    'positions_needed': row[5].strip() if len(row) > 5 else '', # Колонка F - Потребность (ИСПРАВЛЕНО)
                    'manager': row[6].strip() if len(row) > 6 else '',   # Колонка G - Менеджер (ИСПРАВЛЕНО)
                    'company': row[7].strip() if len(row) > 7 else '',   # Колонка H - Юр.лицо (ИСПРАВЛЕНО)
                    'benefits': row[8].strip() if len(row) > 8 else ''   # Колонка I - Преимущества (ИСПРАВЛЕНО)
                })
                
            except Exception as e:
                import traceback
                error_details = {
                    'row_number': i,
                    'row_data': row,
                    'error': str(e),
                    'traceback': traceback.format_exc()
                }
                logger.error(f"Детали ошибки парсинга: {json.dumps(error_details, ensure_ascii=False)}")
                continue
        
        logger.info(f"Пропущено строк: {skipped_rows}")
        logger.info(f"Распарсено вакансий: {len(vacancies)}")
        return vacancies
        
    except Exception as e:
        logger.error(f"Ошибка парсинга CSV: {e}")
        return []

@vacancies_bp.route('/api/vacancies/generate-video', methods=['POST'])
def generate_video():
    """Создание видео через HeyGen для модуля вакансий"""
    data = request.get_json() or {}
    audio_url = (data.get('audio_url') or '').strip()
    avatar_id = data.get('avatar_id') or 'default_avatar'

    if not audio_url:
        return jsonify({'success': False, 'message': 'Аудио URL не передан'}), 400

    try:
        # Получаем API ключ HeyGen
        from models import Settings
        settings = Settings.query.filter_by(module_name='vacancies').first()
        heygen_key = None
        if settings:
            api_keys = settings.get_api_keys()
            heygen_key = api_keys.get('heygen_api_key')
        
        if not heygen_key:
            return jsonify({'success': False, 'message': 'HeyGen API ключ не настроен'}), 400

        # Используем готовый HeyGenClient
        from api.heygen_client import HeyGenClient
        client = HeyGenClient(heygen_key)
        
        # Получаем настройки аватара
        additional = settings.get_additional_settings() if settings else {}
        if avatar_id == 'default_avatar':
            avatar_id = additional.get('default_avatar_id', avatar_id)

        # Получаем video_format из запроса
        video_format = data.get('video_format', 'vertical')
        
        # Создаем видео БЕЗ fallback на placeholder
        video_id = client.create_video(avatar_id, audio_url, video_format)
        
        if not video_id or video_id == "demo_video_id":
            return jsonify({'success': False, 'message': 'HeyGen API вернул ошибку. Проверьте API ключ и аватар.'}), 500

        # Если вернулся прямой URL
        if isinstance(video_id, str) and video_id.startswith('http'):
            return jsonify({'success': True, 'video_url': video_id})

        return jsonify({'success': True, 'video_id': video_id})
        
    except Exception as e:
        print(f"❌ Ошибка генерации видео: {e}")
        return jsonify({'success': False, 'message': f'Ошибка создания видео: {str(e)}'}), 500

@vacancies_bp.route('/api/vacancies/generate-submagic', methods=['POST'])
def generate_submagic():
    """Обработка видео через Submagic для модуля вакансий"""
    data = request.get_json() or {}
    video_url = (data.get('video_url') or '').strip()
    text = (data.get('text') or '').strip()

    if not video_url:
        return jsonify({'success': False, 'message': 'Video URL не передан'}), 400

    if not text:
        return jsonify({'success': False, 'message': 'Текст не передан'}), 400

    try:
        # Получаем API ключ Submagic
        from models import Settings
        settings = Settings.query.filter_by(module_name='vacancies').first()
        submagic_key = None
        if settings:
            api_keys = settings.get_api_keys()
            submagic_key = api_keys.get('submagic_api_key')
        
        if not submagic_key:
            return jsonify({'success': False, 'message': 'Submagic API ключ не настроен'}), 400

        # Используем готовый SubmagicService
        from services.submagic_service import SubmagicService
        service = SubmagicService(submagic_key)
        result = service.process_video(video_url, text)

        return jsonify({'success': True, 'submagic_url': result})
        
    except Exception as e:
        print(f"❌ Ошибка Submagic: {e}")
        return jsonify({'success': False, 'message': f'Ошибка обработки видео: {str(e)}'}), 500

# Тестирование функции
if __name__ == '__main__':
    with open('../test_data/sample_vacancies.csv', 'r', encoding='utf-8') as f:
        csv_data = f.read()
    result = parse_vacancies_direct(csv_data)
    print(f"Найдено вакансий: {len(result)}")
    if result:
        print(f"Первая: {result[0]['position']}")
