import os
from datetime import timedelta

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key-change-in-production'
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///content_factory.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # Upload settings
    UPLOAD_FOLDER = 'uploads'
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file size
    
    # Celery settings for background tasks
    CELERY_BROKER_URL = os.environ.get('REDIS_URL') or 'redis://localhost:6379/0'
    CELERY_RESULT_BACKEND = os.environ.get('REDIS_URL') or 'redis://localhost:6379/0'
    
    # Cloud storage settings
    GOOGLE_CLOUD_PROJECT = os.environ.get('GOOGLE_CLOUD_PROJECT')
    GOOGLE_CLOUD_BUCKET = os.environ.get('GOOGLE_CLOUD_BUCKET')
    
    # API rate limiting
    API_RETRY_ATTEMPTS = 3
    API_RETRY_DELAY = 5  # seconds
    
    # Video settings
    VIDEO_FORMAT = 'mp4'
    VIDEO_ASPECT_RATIO = '9:16'  # Vertical
    AUDIO_DURATION_SECONDS = 40

    # Значения API по умолчанию (можно переопределить через переменные окружения)
    DEFAULT_API_KEYS = {
        'openai_api_key': os.getenv('DEFAULT_OPENAI_API_KEY', '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'),
        'elevenlabs_api_key': os.getenv('DEFAULT_ELEVENLABS_API_KEY', '1d5cd83ef960acc13a1a1dd9a1c87cab2309bc763255060a9ff75203751a1c85'),
        'heygen_api_key': os.getenv('DEFAULT_HEYGEN_API_KEY', 'ZjI2NmI4MGEzOTA0NDIwNzgxNjIzMjdjOWU0N2E3YWEtMTc1NzY3ODAwNw=='),
        'apify_api_key': os.getenv('DEFAULT_APIFY_API_KEY', 'apify_api_k4hgCWSWN687myFIO5vWY4aKzLNbRx0pCK9O'),
        'assemblyai_api_key': os.getenv('DEFAULT_ASSEMBLYAI_API_KEY', '')
    }
