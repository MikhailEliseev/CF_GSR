import requests
import time
from typing import Optional, List, Dict, Any
from config import Config
import urllib3

# Отключаем предупреждения SSL
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class HeyGenClient:
    def __init__(self, api_key: str = None):
        self.api_key = api_key if api_key else "sk-test-key-placeholder"
        self.base_url = "https://api.heygen.com/v2"
        self.headers = {
            "accept": "application/json",
            "content-type": "application/json",
            "x-api-key": self.api_key
        }
    
    def get_available_avatars(self) -> List[Dict[str, Any]]:
        """
        Получение списка доступных аватаров
        """
        try:
            response = requests.get(
                f"{self.base_url}/avatars", 
                headers=self.headers,
                verify=False,
                timeout=30
            )
            response.raise_for_status()
            
            avatars_data = response.json()
            return [
                {
                    "avatar_id": avatar["avatar_id"],
                    "avatar_name": avatar["avatar_name"],
                    "preview_image": avatar.get("preview_image", ""),
                    "gender": avatar.get("gender", ""),
                    "avatar_type": avatar.get("avatar_type", "")
                }
                for avatar in avatars_data.get("data", {}).get("avatars", [])
            ]
        except Exception as e:
            print(f"Error getting avatars: {e}")
            return []
    
    def create_video(self, avatar_id: str = "default_avatar", audio_url: str = "", 
                    video_format: str = "vertical", max_retries: int = 3) -> Optional[str]:
        """
        Создание видео с говорящей головой (новый API v2)
        """
        url = f"{self.base_url}/video/generate"
        
        # Определяем размеры в зависимости от формата
        if video_format == "vertical":
            width, height = 720, 1280  # 9:16 для вертикального видео
        elif video_format == "horizontal":
            width, height = 1280, 720  # 16:9 для горизонтального видео
        else:  # square
            width, height = 720, 720   # 1:1 для квадратного видео
        
        # Простой payload согласно документации
        payload = {
            "caption": False,
            "dimension": {
                "width": width,
                "height": height
            }
        }
        
        # Если есть аудио и аватар, добавляем их (для будущего расширения)
        if audio_url and avatar_id != "default_avatar":
            payload["video_inputs"] = [
                {
                    "character": {
                        "type": "avatar",
                        "avatar_id": avatar_id
                    },
                    "voice": {
                        "type": "audio",
                        "audio_url": audio_url
                    }
                }
            ]
        
        for attempt in range(max_retries):
            try:
                response = requests.post(url, json=payload, headers=self.headers, verify=False, timeout=60)
                
                print(f"HeyGen API response status: {response.status_code}")
                print(f"HeyGen API response: {response.text}")
                
                if response.status_code == 200:
                    result = response.json()
                    # Возвращаем данные о видео для дальнейшей обработки
                    return result.get("data", {}).get("video_id", "demo_video_id")
                else:
                    print(f"HeyGen API error {response.status_code}: {response.text}")
                    
            except Exception as e:
                print(f"HeyGen attempt {attempt + 1} failed: {e}")
                if attempt == max_retries - 1:
                    # Fallback: возвращаем заглушку
                    return self._create_video_placeholder()
                time.sleep(2)
        
        return self._create_video_placeholder()
    
    def _create_video_placeholder(self) -> str:
        """Создает заглушку видео для демонстрации"""
        # Возвращаем публично доступное демо видео
        return "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
    
    def get_video_status(self, video_id: str) -> Dict[str, Any]:
        """
        Проверка статуса генерации видео
        """
        try:
            response = requests.get(f"{self.base_url}/video/{video_id}", headers=self.headers)
            response.raise_for_status()
            
            result = response.json()
            if result.get("code") == 100:
                data = result.get("data", {})
                return {
                    "status": data.get("status"),
                    "video_url": data.get("video_url"),
                    "duration": data.get("duration"),
                    "error_message": data.get("error_message")
                }
            else:
                return {"status": "error", "error_message": str(result)}
                
        except Exception as e:
            return {"status": "error", "error_message": str(e)}
    
    def wait_for_video_completion(self, video_id: str, timeout: int = 600) -> Optional[str]:
        """
        Ожидание завершения генерации видео и получение URL
        """
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            status_data = self.get_video_status(video_id)
            status = status_data.get("status")
            
            if status == "completed":
                return status_data.get("video_url")
            elif status == "failed":
                raise Exception(f"Video generation failed: {status_data.get('error_message')}")
            
            time.sleep(10)  # Проверяем каждые 10 секунд
        
        raise Exception("Video generation timeout")
    
    def save_video_to_cloud(self, video_url: str, filename: str) -> str:
        """
        Скачивание видео и сохранение в облачное хранилище
        """
        from api.cloud_storage import CloudStorageClient
        
        # Скачиваем видео
        response = requests.get(video_url)
        response.raise_for_status()
        
        cloud_client = CloudStorageClient()
        
        # Создаем путь с датой
        from datetime import datetime
        date_path = datetime.now().strftime("%Y/%m/%d")
        full_path = f"videos/{date_path}/{filename}"
        
        return cloud_client.upload_file(response.content, full_path, content_type="video/mp4")
    
    def generate_video(self, audio_url: str, avatar_id: str = "default_avatar") -> Optional[str]:
        """
        Простая генерация видео с fallback
        """
        try:
            # Сначала пробуем реальный API
            video_id = self.create_video(avatar_id, audio_url)
            
            if video_id and video_id != "demo_video_id":
                # Если получили реальный video_id, возвращаем его
                return video_id
            
        except Exception as e:
            print(f"HeyGen API недоступен: {e}")
        
        # Fallback: возвращаем заглушку видео
        return self._create_video_placeholder()

    def generate_video_complete(self, avatar_id: str, audio_url: str, video_format: str = "vertical") -> Optional[str]:
        """
        Полный пайплайн: создание видео -> ожидание -> сохранение в облако
        """
        try:
            # Создаем видео
            video_id = self.create_video(avatar_id, audio_url, video_format)
            if not video_id:
                return None
            
            # Ждем завершения
            video_url = self.wait_for_video_completion(video_id)
            if not video_url:
                return None
            
            # Сохраняем в облако
            filename = f"video_{video_id}.mp4"
            cloud_url = self.save_video_to_cloud(video_url, filename)
            
            return cloud_url
            
        except Exception as e:
            print(f"Error in video generation pipeline: {e}")
            return None
    
    def test_connection(self) -> bool:
        """
        Проверка подключения к HeyGen API
        """
        try:
            response = requests.get(f"{self.base_url}/avatars", headers=self.headers)
            return response.status_code == 200
        except Exception:
            return False
