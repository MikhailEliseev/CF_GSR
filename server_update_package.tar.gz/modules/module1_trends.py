from celery_app import celery_app
from modules.base_module import BaseModule
from models import db, Competitors
from api.apify_client import ApifyInstagramClient
from typing import List, Dict, Any
import json

class TrendModule(BaseModule):
    """
    Модуль трендвотчинга и анализа конкурентов
    """
    
    def __init__(self):
        super().__init__('trends')
        
        # Инициализация Apify клиента
        api_keys = self.settings.get_api_keys()
        apify_key = api_keys.get('apify_api_key')
        if apify_key:
            self.apify_client = ApifyInstagramClient(apify_key)
        else:
            self.apify_client = None
    
    def prepare_context(self, viral_posts: List[Dict] = None) -> str:
        """
        Подготовка контекста на основе вирального контента
        """
        if not viral_posts:
            return "Анализ трендов в социальных сетях"
        
        # Анализируем самые виральные посты
        top_posts = viral_posts[:5]  # Берем топ 5
        
        context_parts = []
        for i, post in enumerate(top_posts, 1):
            context_parts.append(f"""
            Пост {i}:
            - Автор: {post.get('source_username', 'Неизвестно')}
            - Просмотры: {post.get('views_count', 0):,}
            - Лайки: {post.get('likes_count', 0):,}
            - Описание: {post.get('caption', '')[:200]}...
            """)
        
        context = f"""
        Анализ топ {len(top_posts)} вирального контента:
        
        {''.join(context_parts)}
        
        На основе этого анализа создайте текст для видео, который:
        1. Объясняет текущие тренды
        2. Даёт советы по созданию вирального контента
        3. Мотивирует зрителей
        """
        
        return context
    
    def get_competitors(self) -> List[str]:
        """
        Получение списка активных конкурентов
        """
        competitors = Competitors.query.filter_by(is_active=True).all()
        return [comp.username for comp in competitors]
    
    def analyze_competitors(self, days_back: int = 7) -> List[Dict[str, Any]]:
        """
        Анализ контента конкурентов
        """
        if not self.apify_client:
            raise Exception("Apify client not configured")
        
        competitors = self.get_competitors()
        if not competitors:
            raise Exception("No active competitors found")
        
        # Получаем вирусный контент
        viral_posts = self.apify_client.get_trending_content(competitors, days_back)
        
        # Обновляем время последней проверки
        for competitor in competitors:
            comp_obj = Competitors.query.filter_by(username=competitor).first()
            if comp_obj:
                comp_obj.last_checked = db.func.now()
        
        db.session.commit()
        
        return viral_posts
    
    @celery_app.task(bind=True)
    def start_generation(self, task_id: str, days_back: int = 7, 
                        voice_id: str = None, avatar_id: str = None):
        """
        Запуск полного процесса генерации для трендвотчинга
        """
        try:
            module = TrendModule()
            
            # Получаем настройки по умолчанию, если не указаны
            additional_settings = module.settings.get_additional_settings()
            if not voice_id:
                voice_id = additional_settings.get('default_voice_id')
            if not avatar_id:
                avatar_id = additional_settings.get('default_avatar_id')
            
            if not voice_id or not avatar_id:
                raise Exception("Voice ID and Avatar ID must be specified")
            
            # Шаг 1: Анализ конкурентов
            module.update_task_progress(task_id, 5, "Анализ конкурентов...")
            viral_posts = module.analyze_competitors(days_back)
            
            if not viral_posts:
                raise Exception("No viral content found")
            
            # Шаг 2: Подготовка контекста
            module.update_task_progress(task_id, 10, "Подготовка контекста...")
            context = module.prepare_context(viral_posts)
            
            # Шаг 3-6: Выполнение полного пайплайна
            result = module.execute_full_pipeline(task_id, context, voice_id, avatar_id)
            
            # Добавляем данные анализа к результату
            result['viral_posts_analyzed'] = len(viral_posts)
            result['top_viral_post'] = viral_posts[0] if viral_posts else None
            
            module.update_task_progress(task_id, 100, "Готово!", result_data=result)
            
            return result
            
        except Exception as e:
            module = TrendModule()
            module.update_task_progress(task_id, 0, "Ошибка", error_message=str(e))
            raise e
    
    def get_available_voices(self) -> List[Dict]:
        """
        Получение доступных голосов ElevenLabs
        """
        if not self.elevenlabs_client:
            return []
        return self.elevenlabs_client.get_available_voices()
    
    def get_available_avatars(self) -> List[Dict]:
        """
        Получение доступных аватаров HeyGen
        """
        if not self.heygen_client:
            return []
        return self.heygen_client.get_available_avatars()
    
    def test_integrations(self) -> Dict[str, bool]:
        """
        Проверка всех интеграций модуля
        """
        results = {}
        
        if self.apify_client:
            results['apify'] = self.apify_client.test_connection()
        else:
            results['apify'] = False
        
        if self.openai_client and self.settings.openai_assistant_id:
            results['openai'] = self.openai_client.test_connection(self.settings.openai_assistant_id)
        else:
            results['openai'] = False
        
        if self.elevenlabs_client:
            results['elevenlabs'] = self.elevenlabs_client.test_connection()
        else:
            results['elevenlabs'] = False
        
        if self.heygen_client:
            results['heygen'] = self.heygen_client.test_connection()
        else:
            results['heygen'] = False
        
        results['storage'] = self.storage_client.test_connection()
        
        return results
